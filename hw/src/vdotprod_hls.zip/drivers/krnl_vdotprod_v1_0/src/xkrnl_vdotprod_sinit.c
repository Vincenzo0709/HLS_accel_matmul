// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xkrnl_vdotprod.h"

extern XKrnl_vdotprod_Config XKrnl_vdotprod_ConfigTable[];

#ifdef SDT
XKrnl_vdotprod_Config *XKrnl_vdotprod_LookupConfig(UINTPTR BaseAddress) {
	XKrnl_vdotprod_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XKrnl_vdotprod_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XKrnl_vdotprod_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XKrnl_vdotprod_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XKrnl_vdotprod_Initialize(XKrnl_vdotprod *InstancePtr, UINTPTR BaseAddress) {
	XKrnl_vdotprod_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XKrnl_vdotprod_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XKrnl_vdotprod_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XKrnl_vdotprod_Config *XKrnl_vdotprod_LookupConfig(u16 DeviceId) {
	XKrnl_vdotprod_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XKRNL_VDOTPROD_NUM_INSTANCES; Index++) {
		if (XKrnl_vdotprod_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XKrnl_vdotprod_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XKrnl_vdotprod_Initialize(XKrnl_vdotprod *InstancePtr, u16 DeviceId) {
	XKrnl_vdotprod_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XKrnl_vdotprod_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XKrnl_vdotprod_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

